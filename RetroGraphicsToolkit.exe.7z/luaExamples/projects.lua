-- Demonstrates the use of the projects table
print(projects)
print(projects[1])
print(string.format('There are %d project(s)',#projects))
print(string.format('Name of first project: %s',projects[1].name)) -- Lua starts its arrays with one.
