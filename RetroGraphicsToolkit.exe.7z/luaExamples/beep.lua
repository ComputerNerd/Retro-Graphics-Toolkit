fl.beep()
fl.alert("a beep has occurred")
