local ret=fl.ask("Press yes or no")
if ret~=0 then
	fl.message("Yes")
else
	fl.message("No")
end
