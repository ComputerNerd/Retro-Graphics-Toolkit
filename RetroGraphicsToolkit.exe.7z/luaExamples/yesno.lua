local ret=fl.ask("Press yes or no")
if ret~=0 then
	fl.mesasge("Yes")
else
	fl.mesasge("No")
end
