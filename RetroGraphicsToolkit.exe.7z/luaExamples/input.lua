local s=fl.input() -- The two parameters are optional
fl.message("You entered:\n"..s)
