-- Displays what the project does or does not have.
project.haveMessage(project.allMask)
