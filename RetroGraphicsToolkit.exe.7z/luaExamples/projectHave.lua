-- Displays what the project does or does not have.
projects.current:haveMessage(project.allMask)
